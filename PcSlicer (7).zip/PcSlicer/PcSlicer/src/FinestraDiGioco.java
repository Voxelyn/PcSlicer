/**
 *
 * @author malagrino.luisa, franzoni.andrea, singh.anshmeet
 */
import javax.swing.JFrame;
public class FinestraDiGioco extends JFrame{
    
    //public Gioco g = new Gioco(this);
    public FinestraDiGioco(Gioco g){
        this.add(g);
        
        this.pack();
        this.setVisible(true);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setTitle("PcSlicer.exe");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        
        
        
    }
    
}
