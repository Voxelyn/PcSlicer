/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author franzoni.andrea
 */

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;


/**
 *
 * @author singh.anshmeet
 */
public class Gioco extends JPanel implements ActionListener, MouseListener, MouseMotionListener, KeyListener,WindowListener{
    public ArrayList <Componente> componenti = new ArrayList<Componente>();
    public static ArrayList<Point> punti = new ArrayList<Point>();
    public static ArrayList<Integer> punteggi= new ArrayList<Integer>();
    public Timer timer;
    public JLabel titolo;
    public JTextArea punteggio;
    public int cont = 0;
    public boolean gameOver = false;
    public int strike = 0;
    public boolean pausa = false;

    
    
    public Gioco(){
        
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();

        this.setPreferredSize(d);
        
        this.setVisible(true);
        this.setDoubleBuffered(true); // lag meno
        titolo = new JLabel("Score: ");
        titolo.setBounds(30, 30, 50, 50);
        
        punteggio = new JTextArea();
        punteggio.setBounds(100, 60, 50, 50);
        punteggio.setEditable(false);
        
        this.add(titolo);
        this.add(punteggio);
        
        timer = new Timer(1000/60,this);
        timer.start();
        this.addMouseListener(this);
        this.addMouseMotionListener(this); 
        this.addKeyListener(this);
        setFocusable(true);
        /*requestFocusInWindow();
        SwingUtilities.invokeLater(() -> requestFocusInWindow());*/ /*DISCOMMENTA SE SI BUGGA SENZA LORO*/
    }

    
    public void perso(){
        GameOver gO= new GameOver();
        gO.setVisible(true);
        FinestraPrincipale.musica.fermaMusica();
                gO.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                     System.exit(0);
        }
    });
    }
    
    public void actionPerformed(ActionEvent e) {
        if(gameOver){
            timer.stop();
            return;
        }
        
        //SPAWN COMPONENTE
        if(Math.random() < this.getSpawnProbability()){
            try {
                int margineX = (int)(this.getWidth() * 0.05); // margine sinistro
                int larghezzaUtilizzabile = this.getWidth() - (2 * margineX);
                int x = (int)(Math.random() * larghezzaUtilizzabile) + margineX;
                int y = this.getHeight() - (int)(10+(Math.random() * (this.getHeight() * 0.2))) - (int)(this.getHeight() * 0.1);
                int velocitaX = -5 + (int) (Math.random() * 11);
                int velocitaY = 20 + (int) (Math.random() * 10 + this.getSpeedBonus());
                
                
                boolean isBomba = Math.random() < 0.2;
                componenti.add(new Componente(x,y,velocitaX,velocitaY, isBomba));
            } catch (IOException ex) {
                Logger.getLogger(Gioco.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        
        for(Componente x : componenti){
            x.velocita();
        }
        
        Iterator <Componente> iteratore = componenti.iterator();
        
        while(iteratore.hasNext()){
            Componente c = iteratore.next();
            if(c.fuoriSchermo(this.getWidth(), this.getHeight())){
                if(!c.getTagliato() && !c.bomba()){
                    strike++;
                    repaint();
                    if(strike >= 3){
                        timer.stop();
                        FinestraPrincipale.giocaTagliato =false;
                        punteggi.add(cont);
                        perso();
                        Window win = SwingUtilities.getWindowAncestor(this);
                        win.dispose();
                        System.out.println(punteggi);
                                                
                    }
                }
                iteratore.remove();
            }
                
        }
        
        repaint();
    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        for(Componente x : componenti){
            try {
                x.paint(g);
            } catch (IOException ex) {
                Logger.getLogger(Gioco.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if(punti.size() > 1){
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(Color.RED);
            g2.setStroke(new BasicStroke(5));
            for(int i=0; i<punti.size()-1; i++){
                Point p1 = punti.get(i);
                Point p2 = punti.get(i+1);
                
                float alpha = (float) i / (punti.size() - 1); 
                alpha = Math.max(0.1f, alpha); 
                Color colore = FinestraPrincipale.coloreLinea;
                int valoreAlpha = (int)(alpha * 255);
                valoreAlpha = Math.min(255, Math.max(0, valoreAlpha)); // Clamp tra 0 e 255
                Color coloreAlpha = new Color(colore.getRed(), colore.getGreen(), colore.getBlue(), valoreAlpha);
                g2.setColor(coloreAlpha);
                
                g2.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
            
        }
        
        if(strike == 1){
            Graphics2D g2 = (Graphics2D) g;
            
            g2.setColor(Color.red);
            g2.setStroke(new BasicStroke(15));
            
            //PRIMA X
            g2.drawLine(730, 20, 780, 70);
            g2.drawLine(780, 20, 730, 70);
            
        }
        
        if(strike == 2){
            Graphics2D g2 = (Graphics2D) g;
            
            g2.setColor(Color.red);
            g2.setStroke(new BasicStroke(15));
            
            //PRIMA X
            g2.drawLine(730, 20, 780, 70);
            g2.drawLine(780, 20, 730, 70);
            
            //SECONDA X
            g2.drawLine(650, 20, 700, 70);
            g2.drawLine(700, 20, 650, 70);            
        }
        
        if(strike == 3){
            Graphics2D g2 = (Graphics2D) g;
            
            g2.setColor(Color.red);
            g2.setStroke(new BasicStroke(15));
            
            //PRIMA X
            g2.drawLine(730, 20, 780, 70);
            g2.drawLine(780, 20, 730, 70);
            
            //SECONDA X
            g2.drawLine(650, 20, 700, 70);
            g2.drawLine(700, 20, 650, 70);  
            
            //TERZA X
            g2.drawLine(620, 20, 570, 70);
            g2.drawLine(570, 20, 620, 70);  
        }
        
        if(pausa){
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(new Color(0, 0, 0, 150)); // Schermo semi-trasparente
            g2.fillRect(0, 0, this.getWidth(), this.getHeight());

            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Arial", Font.BOLD, 40));
            g2.drawString("MENU PAUSA", 300, 200);

            g2.setFont(new Font("Arial", Font.PLAIN, 30));
            g2.drawString("1. Riprendi", 330, 300);
            g2.drawString("2. Esci", 330, 350);
        }
    }

    public boolean collisioni(Componente x, ArrayList<Point> punti){
        if(punti.size() < 2){
            return false;
        }
        
        double cX = x.getCentrox();
        double cY = x.getCentroY();
        for(int i=0; i<punti.size()-1; i++){
            Point p1 = punti.get(i);
            Point p2 = punti.get(i+1);
            
            double distance = distanza(cX, cY, p1,p2);
            if(distance <= 50){
                return true;
            }
        }
        return false;
    }
    
    public double distanza(double cx, double cy, Point p1, Point p2){
        double A = cx - p1.x;
        double B = cy - p1.y;
        double C = p2.x - p1.x;
        double D = p2.y - p1.y;
        double punto = A * C + B * D;
        double lenSQ = C * C + D * D;
        double param = (lenSQ != 0) ? punto/ lenSQ : -1;
        
        double vicinoX, vicinoY;
        if(param<0){
            vicinoX = p1.x;
            vicinoY = p1.y;
        } else if(param > 1){
            vicinoX = p2.x;
            vicinoY = p2.y;
        } else{
            vicinoX = p1.x + param * C;
            vicinoY = p1.y + param * D;
        }
        double dx = cx - vicinoX;
        double dy = cy - vicinoY;
        
        return Math.sqrt(dx * dx + dy*dy);
    }
    
    public double getSpawnProbability() {
    if (cont < 5) return 0.02;
    if (cont < 15) return 0.03;
    return 0.045; // limite massimo di difficoltà
    }

    public int getSpeedBonus() {
        if (cont < 5) return 0;
        if (cont < 15) return 2;
        return 4; // limite massimo di velocità extra
    }
    
    public void mostraMenuPausa() {
        pausa = true;
        repaint();
    }
    
    public void nascondiMenuPausa() {
        pausa = false;
        repaint();
    }
    
    

    @Override
    public void mousePressed(MouseEvent e) {
        if(gameOver) return;
        punti.clear();
        punti.add(e.getPoint());
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        punti.clear();
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        
        Point nuovoPunto = e.getPoint();
        punti.add(nuovoPunto);
        

        this.punteggio.setText(cont+"");
        if(punti.size() > 2){
            for(Componente x : componenti){
                if(!x.getTagliato()){
                    if(collisioni(x, punti)){
                        x.setTagliato(true);
                        cont++; //punti 
                        if(x.bomba()){
                            gameOver = true;
                            punteggi.add(cont-1);
                            FinestraPrincipale.giocaTagliato =false;
                            System.out.println(punteggi);
                            perso();
                            JComponent comp = (JComponent) e.getSource();
                            Window win = SwingUtilities.getWindowAncestor(comp);
                            win.dispose();
                        }
                    }
                }
            }
        }
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
            mostraMenuPausa();
            timer.stop();
        } else if(pausa){
            if(e.getKeyCode() == KeyEvent.VK_1){
                this.nascondiMenuPausa();
                timer.start();
                
            }
            else if(e.getKeyCode() == KeyEvent.VK_2){
                timer.stop();
                System.out.println("timer fermo");
                JComponent comp = (JComponent) e.getSource();
                Window win = SwingUtilities.getWindowAncestor(comp);
                win.dispose();
                FinestraPrincipale.giocaTagliato = false;
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //METODI MOUSE NON USATI
    public void mouseMoved(MouseEvent e) {
    }
    
    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }
    
    public void mouseClicked(MouseEvent e) {
    }

    
    //METODI TASTIERA NON USATI
    public void keyTyped(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void windowOpened(WindowEvent e) {
    }

    @Override
    public void windowClosing(WindowEvent e) {
        timer.stop();
                        System.exit(0);


    }

    @Override
    public void windowClosed(WindowEvent e) {
    }

    @Override
    public void windowIconified(WindowEvent e) {
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
    }

    @Override
    public void windowActivated(WindowEvent e) {
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
    }

    
    
    
}
