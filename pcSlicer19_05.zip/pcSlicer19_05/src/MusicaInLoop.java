
import java.io.*;
import javax.sound.sampled.*;

/**
 *
 * @author malagrino.luisa, franzoni.andrea, singh.anshmeet
 */
public class MusicaInLoop {
    // Oggetto Clip per controllare la riproduzione audio
    private Clip clip;

    // Metodo per avviare la musica da un file .wav
    public void avviaMusica(String percorsoFile) {
        try {
            // Crea un oggetto File dal percorso fornito
            File fileAudio = new File(percorsoFile);

            // Verifica se il file esiste
            if (!fileAudio.exists()) {
                System.out.println("File audio non trovato: " + percorsoFile);
                return; // Esce dal metodo se il file non esiste
            }

            // Crea uno stream audio dal file
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(fileAudio);

            // Ottiene una Clip (contenitore audio) dal sistema audio
            clip = AudioSystem.getClip();

            // Apre lo stream audio nella clip (carica il file)
            clip.open(audioStream);
            FloatControl gainControl = 
            (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            gainControl.setValue(-20.0f); // Reduce volume by 10 decibels.
            // Imposta il clip per riprodursi in loop continuo
            clip.loop(Clip.LOOP_CONTINUOUSLY);

            // Avvia la riproduzione della clip
            clip.start();

            // Messaggio di conferma
            System.out.println("Musica avviata in loop!");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            // Gestisce eventuali errori legati al file audio o al sistema audio
            e.printStackTrace();
        }
    }

    // Metodo per fermare la musica e rilasciare le risorse
    public void fermaMusica() {
        // Se la clip è attiva
        if (clip != null) {
            clip.stop();   // Ferma la riproduzione
            clip.close();  // Chiude la clip e libera le risorse
        }
    }

    // Metodo main: punto di partenza del programma
    public static void main(String[] args) {
        // Crea un oggetto della classe MusicaInLoop
        MusicaInLoop musica = new MusicaInLoop();

        // Avvia la musica specificando il percorso del file audio .wav
        musica.avviaMusica("inMenu.wav"); // Sostituisci con il tuo file audio

        // La musica continua a suonare finché il programma è in esecuzione
    }
}
