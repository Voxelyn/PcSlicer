/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author franzoni.andrea
 */


/**
 *
 * @author singh.anshmeet
 */
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class Componente {
    public int x,y;
    public int velX,velY;
    public Color colore;
    public boolean taglio, flagBomba;
    public Image immagine, bomba;
    private String immagini[]={"cpu.png","gpu.png","ventola.png","monitor.png","tastiera.png"};
    
    public Componente(int coordX, int coordY, int veloX, int veloY, boolean fBomba) throws IOException{
        this.x = coordX;
        this.y = coordY;
        this.velX = veloX;
        this.velY = veloY;
        this.flagBomba = fBomba;
        
        int index = (int) (Math.random() * immagini.length);
        immagine = ImageIO.read(new File(immagini[index]));
        if (index == 0 || index == 2) {
            immagine = immagine.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        } else if (index == 4) {
            immagine = immagine.getScaledInstance(260, 100, Image.SCALE_DEFAULT);
        } else {
            immagine = immagine.getScaledInstance(160, 100, Image.SCALE_DEFAULT);
        }

        
        System.out.println(immagine.getClass());
        bomba= ImageIO.read(new File("alimentatore.png"));
        System.out.println(bomba.getClass());
    }

            
        
     
    
    public void paint(Graphics g) throws IOException{
        
        if(!this.getTagliato()){
            if(flagBomba) g.drawImage(bomba, x, y, 160, 160, null);  

            else g.drawImage(immagine, x, y, immagine.getWidth(null), immagine.getHeight(null), null); 
        }
    }
    
    public void velocita(){
        this.y -= this.velY;
        this.velY -= 1;
        
        this.x += this.velX;
        
          if (this.x < 0) {  // Se il componente supera il bordo sinistro della finestra (0px)
        this.x = 0;     // Impostalo esattamente alla parte sinistra della finestra
        }
        if (this.x > (Toolkit.getDefaultToolkit().getScreenSize().width)) {  // Se il componente supera il bordo destro della finestra (800px)
        this.x = (Toolkit.getDefaultToolkit().getScreenSize().width);    // Impostalo esattamente alla parte destra della finestra
        }
    }
    
    public boolean fuoriSchermo(int larghezza, int altezza){
        if(this.y > altezza || this.x < -50 || this.x > larghezza+50) {return true;}
        return false;
    }
    
    public void setTagliato(boolean t){
        this.taglio = t;
    }
    public boolean getTagliato(){
        return taglio;
    }
    public Color getColor(){
        return colore;
    }
    
    public boolean bomba(){
        return flagBomba;
    }
    
    public int getCentrox(){
        return x + 25;
    }
    
    public int getCentroY(){
        return y + 25;
    }
    
    
    
    
    
}
