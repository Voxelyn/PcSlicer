
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Path2D;
import java.util.ArrayList;
import javax.swing.*;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author malagrino.luisa
 */
public class GameOver extends javax.swing.JFrame implements MouseListener, MouseMotionListener{

    /**
     * Creates new form GameOver
     */
    public static ArrayList<Point> punti = new ArrayList<Point>();
    public boolean cancella = false; 
    public GameOver() {
        initComponents();
        this.getContentPane().setBackground(new Color(152, 121, 184));
        this.setSize((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(), (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight());

        
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.setVisible(false);
        
        
        gameOver.setIcon(new ImageIcon("gameOver.png"));
        explosion.setIcon(new ImageIcon("explosion.png"));
        bottoneRigioca.setIcon(new ImageIcon("bottoneRigioca.png"));
        bottoneMenu.setIcon(new ImageIcon("bottoneMenu.png"));

        

        
        
        int centerX = this.getWidth() / 2;
        int centerY=  this.getHeight() / 2;

        gameOver.setLocation(centerX - gameOver.getWidth()/2, gameOver.getY());
        explosion.setLocation(centerX - explosion.getWidth()/2-50, centerY-explosion.getHeight()/2 );

        bottoneRigioca.setLocation(centerX - bottoneRigioca.getWidth()/2, this.getHeight() - 500);
        bottoneMenu.setLocation(centerX - bottoneMenu.getWidth()/2, this.getHeight() - 200 );
 
    
        
        
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }

    
    
    public double distanza(double cx, double cy, Point p1, Point p2){
        double A = cx - p1.x;
        double B = cy - p1.y;
        double C = p2.x - p1.x;
        double D = p2.y - p1.y;
        double punto = A * C + B * D;
        double lenSQ = C * C + D * D;
        double param = (lenSQ != 0) ? punto/ lenSQ : -1;
       
        double vicinoX, vicinoY;
        if(param<0){
            vicinoX = p1.x;
            vicinoY = p1.y;
        } else if(param > 1){
            vicinoX = p2.x;
            vicinoY = p2.y;
        } else{
            vicinoX = p1.x + param * C;
            vicinoY = p1.y + param * D;
        }
        double dx = cx - vicinoX;
        double dy = cy - vicinoY;
       
        return Math.sqrt(dx * dx + dy*dy);
    }
    
    
    
    @Override
    public void paint(Graphics g) {
    super.paint(g);
    if (!cancella && punti.size() > 1) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        
        // Create a single path instead of drawing individual lines
        Path2D path = new Path2D.Float();
        path.moveTo(punti.get(0).x, punti.get(0).y);
        for (int i = 1; i < punti.size(); i++) {
            path.lineTo(punti.get(i).x, punti.get(i).y);
            float alpha = (float) i / (punti.size() - 1); 
                alpha = Math.max(0.1f, alpha); 
                Color colore = FinestraPrincipale.coloreLinea;
                int valoreAlpha = (int)(alpha * 255);
                valoreAlpha = Math.min(255, Math.max(0, valoreAlpha)); // Clamp tra 0 e 255
                Color coloreAlpha = new Color(colore.getRed(), colore.getGreen(), colore.getBlue(), valoreAlpha);
                g2.setColor(coloreAlpha);
                g2.setColor(FinestraPrincipale.coloreLinea);
        }
        g2.draw(path);
    }
}
    
    

    public boolean collisioni(){
        
        
        //BOTTONE MENU
        int mX = bottoneMenu.getX() + bottoneMenu.getWidth() / 2;
        int mY = bottoneMenu.getY() + bottoneMenu.getHeight() / 2;
        
        //BOTTONE RIGIOCA
        int rX = bottoneRigioca.getX() + bottoneRigioca.getWidth() / 2;
        int rY = bottoneRigioca.getY() + bottoneRigioca.getHeight() / 2;
        
        
        int areaMenu= Math.max(bottoneMenu.getWidth(), bottoneMenu.getHeight()) / 2;
        int areaRigioca=Math.max(bottoneRigioca.getWidth(), bottoneRigioca.getHeight()) / 2;
        
        
        for(int i=0; i<punti.size()-1; i++){
            Point p1 = punti.get(i);
            Point p2 = punti.get(i+1);
            
            double distanzaMenu = distanza(mX, mY, p1, p2);
            double distanzaRigioca = distanza(rX, rY, p1, p2);
            
            if(distanzaRigioca <= areaRigioca){
                FinestraPrincipale.giocaTagliato = true;
                this.setVisible(false);
                Gioco g = new Gioco();
                FinestraDiGioco f = new FinestraDiGioco(g);
                System.out.println("TAGLIATO SEEEEEE");
                FinestraPrincipale.musica.fermaMusica();
                if(Opzioni.flagMuta == true){
                    System.out.println("Musica menu fermata!");
                    FinestraPrincipale.musica.avviaMusica("inGame.wav");
                    System.out.println("Musica gioco avviata!");
                }
                
                
                break;
            }else if(distanzaMenu <= areaMenu){
                this.setVisible(false);
                FinestraPrincipale fP = new FinestraPrincipale();
                fP.setVisible(true);
                if(Opzioni.flagMuta == true){
                    System.out.println("Musica menu fermata!");
                    FinestraPrincipale.musica.avviaMusica("inMenu.wav");
                    System.out.println("Musica gioco avviata!");
                }
            }
            
           
            
        
        
        }
        return false;
       
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        gameOver = new javax.swing.JLabel();
        bottoneRigioca = new javax.swing.JLabel();
        bottoneMenu = new javax.swing.JLabel();
        explosion = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(gameOver, new org.netbeans.lib.awtextra.AbsoluteConstraints(164, 50, 884, 138));
        getContentPane().add(bottoneRigioca, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 75, 420, 80));
        getContentPane().add(bottoneMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 25, 720, 90));
        getContentPane().add(explosion, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, -30, 1300, 1086));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GameOver.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GameOver.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GameOver.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GameOver.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GameOver().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bottoneMenu;
    private javax.swing.JLabel bottoneRigioca;
    private javax.swing.JLabel explosion;
    private javax.swing.JLabel gameOver;
    // End of variables declaration//GEN-END:variables

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        punti.clear();
        punti.add(e.getPoint());
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        punti.clear();
        repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        punti.add(e.getPoint());
        collisioni();
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        
    }
}
