
import java.io.*;
import javax.sound.sampled.*;

/**
 *
 * @author malagrino.luisa, franzoni.andrea, singh.anshmeet
 */
public class MusicaInLoop {
    private Clip clip;

    public void avviaMusica(String percorsoFile) {
        try {
            File fileAudio = new File(percorsoFile);

            if (!fileAudio.exists()) {
                System.out.println("File audio non trovato: " + percorsoFile);
                return;
            }

            /*carica i dati audio da un file in un AudioInputStream.

            contenitore (Clip) può riprodurre i dati audio.

            carica i dati nel contenitore audio (Clip).

            imposta il Clip per riprodurre il suono in loop continuo.

            avvia la canzone.*/
            
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(fileAudio);

            clip = AudioSystem.getClip();

            clip.open(audioStream);

            clip.loop(Clip.LOOP_CONTINUOUSLY);

            clip.start();

            System.out.println("Musica avviata in loop!");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    public void fermaMusica() {
        if (clip != null) {
            clip.stop();
            clip.close();
        }
    }

    public static void main(String[] args) {
        MusicaInLoop musica = new MusicaInLoop();

        musica.avviaMusica("canzoncina.wav");

    }
}
