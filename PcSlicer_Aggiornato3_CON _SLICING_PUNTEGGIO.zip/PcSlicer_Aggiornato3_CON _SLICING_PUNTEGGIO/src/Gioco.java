
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;


/**
 *
 * @author singh.anshmeet
 */
public class Gioco extends JFrame implements ActionListener, MouseListener, MouseMotionListener{
    public ArrayList <Componente> componenti = new ArrayList<Componente>();
    public ArrayList <Point> punti = new ArrayList<Point>(); //punti Tracciati
    public Timer timer;
    public JLabel titolo;
    public JTextArea punteggio;
    public int cont = 0;
    
    
    public Gioco(){
        this.setSize(800, 600);
        this.setBackground(Color.black);
        this.setVisible(true);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setTitle("PcSlicer.exe");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        
        titolo = new JLabel("Score: ");
        titolo.setBounds(30, 30, 50, 50);
        
        punteggio = new JTextArea();
        punteggio.setBounds(100, 60, 50, 50);
        punteggio.setEditable(false);
        
        this.add(titolo);
        this.add(punteggio);
        
        timer = new Timer(1000/60,this);
        timer.start();
        this.addMouseListener(this);
        this.addMouseMotionListener(this);   
    }

    public void actionPerformed(ActionEvent e) {
        if(Math.random() < 0.03){
            int x = (int)(Math.random() * this.getWidth());
            int y = this.getHeight();
            int velocitaX = -5 + (int) (Math.random() * 11);
            int velocitaY = 20 + (int) (Math.random() * 10);
            
            int bit = (int) Math.round(Math.random());
            int r,g,b;
            
            if(bit == 0){
                r = 0;
                g = 0;
                b = 0;
            }
            else{
                r = 255;
                g = 0;
                b = 0;
            }
            boolean isBomba = Math.random() < 0.2;
            componenti.add(new Componente(x,y,velocitaX,velocitaY, isBomba));
            
        }
        
        for(Componente x : componenti){
            x.velocita();
        }
        
        repaint();
    }
    
    public void paint(Graphics g){
        super.paint(g);
        
        for(Componente x : componenti){
            x.paint(g);
        }
        
        if(punti.size() > 1){
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(Color.RED);
            g2.setStroke(new BasicStroke(5));
            for(int i=0; i<punti.size()-1; i++){
                Point p1 = punti.get(i);
                Point p2 = punti.get(i+1);
                g2.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
            
        }
    }
    public boolean collisioni(Point punto, Componente x){
        int dx = punto.x - (x.x + 25);
        int dy = punto.y - (x.y + 25);
        
        return (dx*dx)+(dy*dy) <= (50*50);
    }
    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        punti.clear();
        punti.add(e.getPoint());
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        punti.clear();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        Point nuovoPunto = e.getPoint();
        punti.add(nuovoPunto);
        for (Componente x : componenti){
            
            if(! x.getTagliato() && this.collisioni(nuovoPunto, x)){
                
                x.setTagliato(true);
                
                if(x.bomba()){
                    cont = 0;
                    punteggio.setText(null);
                    JOptionPane.showMessageDialog(this, "GAME OVER", "ATTENZIONE!", JOptionPane.WARNING_MESSAGE);
                    timer.stop();
                    
                }
                else{
                    cont ++;
                    punteggio.setText(cont+"");
                }
                
                    
            }
        }
        
        System.out.println("conto punti: " + punti.size());
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }
    
    
}
