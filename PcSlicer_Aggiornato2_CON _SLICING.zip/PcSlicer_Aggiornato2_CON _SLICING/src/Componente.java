

/**
 *
 * @author singh.anshmeet
 */
import java.awt.*;

public class Componente {
    public int x,y;
    public int velX,velY;
    public Color colore;
    public boolean taglio;
    
    public Componente(int coordX, int coordY, int veloX, int veloY, int r, int g, int b){
        this.x = coordX;
        this.y = coordY;
        this.velX = veloX;
        this.velY = veloY;
        colore = new Color(r,g,b);
    }
    
    public void paint(Graphics g){
        g.setColor(colore);
        g.fillOval(x, y, 50, 50);
    }
    
    public void velocita(){
        this.y -= this.velY;
        this.velY -= 1;
        
        this.x += this.velX;
        //this.velX *= 0.99;
    }
    
    public void setTagliato(boolean t){
        this.taglio = t;
    }
    public boolean getTagliato(){
        return taglio;
    }
    
    
    
    
}
