import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author franzoni.andrea
 */
public class Opzioni extends javax.swing.JFrame implements MouseListener, MouseMotionListener{

    public ArrayList<Point> punti = new ArrayList<Point>(); // punti tracciati
    public boolean cancella = false;


    public Opzioni() {
        initComponents();
        this.setSize((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(), (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight());
        
        this.setTitle("PcSlicer.exe");
 
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
        opzioni.setIcon(new ImageIcon("OPZIONI.png"));
        viola.setOpaque(true);
        viola.setBackground((new Color(160, 32, 240)));
        rosso.setOpaque(true);
        rosso.setBackground(Color.red);
        giallo.setOpaque(true);
        giallo.setBackground(Color.yellow);
        nero.setOpaque(true);
        nero.setBackground(Color.BLACK);
        azzurro.setOpaque(true);
        azzurro.setBackground(Color.cyan);
        verde.setOpaque(true);
        verde.setBackground(Color.GREEN);
       
        int centerX = this.getContentPane().getWidth() / 2;
    

        opzioni.setLocation(centerX - opzioni.getWidth()/2, opzioni.getY());
        viola.setLocation(centerX - viola.getWidth()/2, viola.getY());
        rosso.setLocation(centerX - rosso.getWidth()/2, rosso.getY());
        giallo.setLocation(centerX - giallo.getWidth()/2, giallo.getY());
        nero.setLocation(centerX - nero.getWidth()/2, nero.getY());
        azzurro.setLocation(centerX - azzurro.getWidth()/2, azzurro.getY());
        verde.setLocation(centerX - verde.getWidth()/2, verde.getY());
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }
   
    public boolean collisioni(){
        int vX=viola.getX() + viola.getWidth() / 2;
        int vY=viola.getY() + viola.getHeight() / 2;
       
        int rX=rosso.getX() + rosso.getWidth() / 2;
        int rY=rosso.getY() + rosso.getHeight() / 2;
       
        int gX=giallo.getX() + giallo.getWidth() / 2;
        int gY=giallo.getY() + giallo.getHeight() / 2;
       
        int nX=nero.getX() + nero.getWidth() / 2;
        int nY=nero.getY() + nero.getHeight() / 2;
       
        int aX=azzurro.getX() + azzurro.getWidth() / 2;
        int aY=azzurro.getY() + azzurro.getHeight() / 2;
       
        int veX=verde.getX() + verde.getWidth() / 2;
        int veY=verde.getY() + verde.getHeight() / 2;
       
        int areaViola= Math.max(viola.getWidth(), viola.getHeight()) / 2;
        int areaRosso= Math.max(rosso.getWidth(), rosso.getHeight()) / 2;
        int areaGiallo= Math.max(giallo.getWidth(), giallo.getHeight()) / 2;
        int areaNero= Math.max(nero.getWidth(), nero.getHeight()) / 2;
        int areaAzzurro= Math.max(azzurro.getWidth(), azzurro.getHeight()) / 2;
        int areaVerde= Math.max(verde.getWidth(), verde.getHeight()) / 2;
       
        for(int i=0; i<punti.size()-1; i++){
            Point p1 = punti.get(i);
            Point p2 = punti.get(i+1);
           
            double distanzaViola=distanza(vX, vY, p1, p2);
            double distanzaRosso=distanza(rX, rY, p1, p2);
            double distanzaGiallo=distanza(gX, gY, p1, p2);
            double distanzaNero=distanza(nX, nY, p1, p2);
            double distanzaAzzurro=distanza(aX, aY, p1, p2);
            double distanzaVerde=distanza(veX, veY, p1, p2);
           
            if(distanzaViola<=areaViola){
                FinestraPrincipale.coloreLinea = new Color(160, 32, 240);
                return true;
            }
            else if(distanzaRosso<=areaRosso){
                FinestraPrincipale.coloreLinea =Color.red;
                return true;
            }
            else if(distanzaGiallo<=areaGiallo){
                FinestraPrincipale.coloreLinea =Color.yellow;
                return true;
            }
            else if(distanzaNero<=areaNero){
                FinestraPrincipale.coloreLinea=Color.black;
                return true;
            }
            else if(distanzaAzzurro<=areaAzzurro){
                FinestraPrincipale.coloreLinea=Color.cyan;
                return true;
            }
            else if(distanzaVerde<=areaVerde){
                FinestraPrincipale.coloreLinea=Color.green;
                return true;
            }
        }
       
       
        return false;
    }
   
    public double distanza(double cx, double cy, Point p1, Point p2){
        double A = cx - p1.x;
        double B = cy - p1.y;
        double C = p2.x - p1.x;
        double D = p2.y - p1.y;
        double punto = A * C + B * D;
        double lenSQ = C * C + D * D;
        double param = (lenSQ != 0) ? punto/ lenSQ : -1;
       
        double vicinoX, vicinoY;
        if(param<0){
            vicinoX = p1.x;
            vicinoY = p1.y;
        } else if(param > 1){
            vicinoX = p2.x;
            vicinoY = p2.y;
        } else{
            vicinoX = p1.x + param * C;
            vicinoY = p1.y + param * D;
        }
        double dx = cx - vicinoX;
        double dy = cy - vicinoY;
       
        return Math.sqrt(dx * dx + dy*dy);
    }
   
   
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        // Disegna le linee
        if (!cancella && punti.size() > 1) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(FinestraPrincipale.coloreLinea);
            g2.setStroke(new BasicStroke(5));
            for (int i = 0; i < punti.size() - 1; i++) {
                Point p1 = punti.get(i);
                Point p2 = punti.get(i + 1);
                g2.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        opzioni = new javax.swing.JLabel();
        viola = new javax.swing.JLabel();
        rosso = new javax.swing.JLabel();
        verde = new javax.swing.JLabel();
        azzurro = new javax.swing.JLabel();
        giallo = new javax.swing.JLabel();
        nero = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(opzioni, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 21, 320, 100));
        getContentPane().add(viola, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 175, 101, 100));
        getContentPane().add(rosso, new org.netbeans.lib.awtextra.AbsoluteConstraints(406, 175, 101, 100));
        getContentPane().add(verde, new org.netbeans.lib.awtextra.AbsoluteConstraints(607, 175, 101, 100));
        getContentPane().add(azzurro, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 385, 101, 100));
        getContentPane().add(giallo, new org.netbeans.lib.awtextra.AbsoluteConstraints(406, 385, 101, 100));
        getContentPane().add(nero, new org.netbeans.lib.awtextra.AbsoluteConstraints(607, 385, 101, 100));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Opzioni.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Opzioni.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Opzioni.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Opzioni.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Opzioni().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel azzurro;
    private javax.swing.JLabel giallo;
    private javax.swing.JLabel nero;
    private javax.swing.JLabel opzioni;
    private javax.swing.JLabel rosso;
    private javax.swing.JLabel verde;
    private javax.swing.JLabel viola;
    // End of variables declaration//GEN-END:variables

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        punti.clear();
        punti.add(e.getPoint());
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        punti.clear();
        repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        punti.add(e.getPoint());
        collisioni();
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        
    }
}
