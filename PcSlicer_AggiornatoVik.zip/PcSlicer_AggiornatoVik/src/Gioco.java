
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;


/**
 *
 * @author singh.anshmeet
 */
public class Gioco extends JFrame implements ActionListener{
    public ArrayList <Componente> componenti = new ArrayList<Componente>();
    public Timer timer;
    String[] immagini = {"stella.png"};

    public Gioco(){
        this.setSize(800, 600);
        this.setBackground(Color.black);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        timer = new Timer(1000/60,this);
        timer.start();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(Math.random() < 0.1){
            int x = (int)(Math.random() * this.getWidth());
            int y = this.getHeight();
            int velocitaX = -3 + (int) (Math.random() * 6);
            int velocitaY = 15 + (int) (Math.random() * 10);
            
            int bit = (int) Math.round(Math.random());
            int r,g,b;
            
            if(bit == 0){
                r = 0;
                g = 0;
                b = 0;
            }
            else{
                r = 255;
                g = 0;
                b = 0;
            }
            
            componenti.add(new Componente(x,y,velocitaX,velocitaY,r,g,b));
            
        }
        
        for(Componente x : componenti){
            x.velocita();
        }
        
        repaint();
    }
    
    public void paint(Graphics g){
        super.paint(g);
        for(Componente x : componenti){
            try {
                x.paint(g);
            } catch (IOException ex) {
                Logger.getLogger(Gioco.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
}
