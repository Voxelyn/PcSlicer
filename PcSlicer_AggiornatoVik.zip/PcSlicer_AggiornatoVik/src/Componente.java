

/**
 *
 * @author singh.anshmeet
 */
import java.awt.*;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Componente {
    public int x, y;
    public int velX, velY;
    public Color colore;
    private Image immagine; // Variabile per l'immagine
    private String immagini[]={"stella.png","luna.png","deagle.png"};
    public Componente(int coordX, int coordY, int veloX, int veloY, int r, int g, int b) {
        this.x = coordX;
        this.y = coordY;
        this.velX = veloX;
        this.velY = veloY;
        this.colore = new Color(r, g, b);

        try {
            // Seleziona un'immagine random una sola volta all'inizio
            int index = (int) (Math.random() * immagini.length);
            immagine = ImageIO.read(new File(immagini[index]));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void paint(Graphics g) throws IOException {
        if (immagine != null) {
            
            g.drawImage(immagine, x, y, 50, 50, null); // Puoi modificare la dimensione (50, 50)
        }
    }

    public void velocita() {
        this.y -= this.velY;
        this.velY -= 1;

        this.x += this.velX;
        // this.velX *= 0.99;  // Se vuoi ridurre lentamente la velocità orizzontale
    }
}
