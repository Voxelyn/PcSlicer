/**
 *
 * @author franzoni.andrea
 */
import javax.swing.JFrame;
public class FinestraOpzioni extends JFrame{
    public FinestraOpzioni(Opzioni o){
        this.add(o);
        
        this.pack();
        this.setVisible(true);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setTitle("PcSlicer.exe");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
