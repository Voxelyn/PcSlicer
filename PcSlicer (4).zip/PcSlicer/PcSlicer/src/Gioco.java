
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;


/**
 *
 * @author singh.anshmeet
 */
public class Gioco extends JFrame implements MouseListener, MouseMotionListener{
    public ArrayList <Point> punti = new ArrayList<Point>(); //punti Tracciati
    public Timer timer;
    
    public Gioco(){
        this.setSize(800, 600);
        this.setBackground(Color.black);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setTitle("PcSlicer.exe");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        //timer = new Timer(1000/60,this);
        //timer.start();
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }

    /*public void actionPerformed(ActionEvent e) {
        if(Math.random() < 0.03){
            int x = (int)(Math.random() * this.getWidth());
            int y = this.getHeight();
            int velocitaX = -5 + (int) (Math.random() * 11);
            int velocitaY = 20 + (int) (Math.random() * 10);
            
            int bit = (int) Math.round(Math.random());
            int r,g,b;
            
            if(bit == 0){
                r = 0;
                g = 0;
                b = 0;
            }
            else{
                r = 255;
                g = 0;
                b = 0;
            }
            
            componenti.add(new Componente(x,y,velocitaX,velocitaY,r,g,b));
            
        }
        
        for(Componente x : componenti){
            x.velocita();
        }
        
        repaint();
    }*/
    
    public void paint(Graphics g){
        super.paint(g);
        
        /*for(Componente x : componenti){
            x.paint(g);
        }*/
        
        if(punti.size() > 1){
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(Color.RED);
            g2.setStroke(new BasicStroke(5));
            for(int i=0; i<punti.size()-1; i++){
                Point p1 = punti.get(i);
                Point p2 = punti.get(i+1);
                g2.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
            
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        punti.clear();
        punti.add(e.getPoint());
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        punti.clear();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        Point nuovoPunto = e.getPoint();
        punti.add(nuovoPunto);
        System.out.println("conto punti: " + punti.size());
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }
    
    
}
